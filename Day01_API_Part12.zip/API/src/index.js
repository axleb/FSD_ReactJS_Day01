import React from 'react';
import ReactDOM from 'react-dom';
import Header from './components/header';
import './styles.css';
//
const Index = () => {
  return <div> <Header /> <h2>Welcome to Skillsoft Live Learning</h2></div>;
};
//
ReactDOM.render(<Index />, document.getElementById('root'));
