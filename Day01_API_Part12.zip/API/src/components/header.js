import React from 'react';
//
function Header() {
  return <h3>Hello Function Component!</h3>;
}
//
export default Header;
